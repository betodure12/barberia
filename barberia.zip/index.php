<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
  <meta name="theme-color" content="#0a0d14">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="color-scheme" content="dark">
  <meta name="format-detection" content="telephone=no">
  <title>MF Barber &amp; Lounge - Sistema de Gestión</title>
  
  <!-- Favicon -->
  <link rel="icon" type="image/jpeg" href="assets/img/logo.jpg">
  <link rel="apple-touch-icon" href="assets/img/logo.jpg">
  
  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="assets/css/bootstrap-icons.min.css">
  
  <!-- Custom Stylesheets -->
  <link rel="stylesheet" href="assets/css/style.css?v=<?= time() ?>">
  <link rel="stylesheet" href="assets/css/components.css?v=<?= time() ?>">
  <link rel="stylesheet" href="assets/css/mobile.css?v=<?= time() ?>">
</head>
<body>

<div class="app-container">
  
  <!-- Sidebar Navigation -->
  <aside class="sidebar">
    <div class="sidebar-header">
      <div class="brand-logo-wrap">
        <img src="assets/img/logo.jpg" alt="MF Barber Logo" class="brand-logo-img">
      </div>
      <div class="brand-info">
        <h2>MF BARBER</h2>
        <span>& LOUNGE SYSTEM</span>
      </div>
    </div>

    <nav class="sidebar-nav">
      <div class="nav-section-title">Operaciones Diarias</div>
      <a class="nav-item active" data-view="welcome">
        <i class="bi bi-house-door-fill"></i>
        <span>Inicio / Bienvenida</span>
        <span class="nav-badge gold">HOME</span>
      </a>
      <a class="nav-item" data-view="appointments">
        <i class="bi bi-calendar-week-fill"></i>
        <span>Turnos de Hoy</span>
        <span class="nav-badge gold" id="badge-nav-turnos">Agenda</span>
      </a>
      <a class="nav-item" data-view="pos">
        <i class="bi bi-lightning-charge-fill"></i>
        <span>Venta Rápida (Caja)</span>
        <span class="nav-badge emerald">POS</span>
      </a>
      <a class="nav-item" data-view="clients">
        <i class="bi bi-people-fill"></i>
        <span>Clientes & Fichas</span>
      </a>

      <div class="nav-section-title">Control & Finanzas</div>
      <a class="nav-item" data-view="inventory">
        <i class="bi bi-box-seam-fill"></i>
        <span>Stock & Inventario</span>
        <span class="nav-badge danger" id="badge-low-stock" style="display: none;">0</span>
      </a>
      <a class="nav-item" data-view="sales">
        <i class="bi bi-bar-chart-line-fill"></i>
        <span>Reportes & Ventas</span>
      </a>
      <a class="nav-item" data-view="services">
        <i class="bi bi-scissors"></i>
        <span>Cortes & Servicios</span>
      </a>
      <a class="nav-item" data-view="dashboard">
        <i class="bi bi-grid-1x2-fill"></i>
        <span>Panel Estadístico</span>
      </a>

      <div class="nav-section-title">Ajustes & Sistema</div>
      <a class="nav-item" onclick="App.openSettingsModal()" style="cursor: pointer;" title="Configuración del negocio y tickets">
        <i class="bi bi-gear-fill"></i>
        <span>Configuración</span>
      </a>
      <a class="nav-item" onclick="App.syncOfflineData()" style="cursor: pointer;" title="Sincronizar datos locales con el servidor">
        <i class="bi bi-cloud-arrow-up-fill"></i>
        <span>Sincronizar Nube</span>
      </a>

      <div class="nav-section-title master-only" style="display: none;">Seguridad & Licencia</div>
      <a class="nav-item master-only" onclick="Auth.openMasterControlModal()" style="display: none; cursor: pointer;">
        <i class="bi bi-shield-lock-fill" style="color: var(--gold-primary);"></i>
        <span>Control Licencia Demo</span>
        <span class="nav-badge gold" id="badge-nav-master">MAESTRO</span>
      </a>
    </nav>

    <div class="sidebar-footer" style="flex-direction: column; align-items: stretch; gap: 8px;">
      <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px;">
        <div style="display: flex; align-items: center; gap: 8px; min-width: 0;">
          <img src="assets/img/logo.jpg" alt="MF Barber" loading="lazy" style="width: 32px; height: 32px; border-radius: 50%; object-fit: cover; border: 1.5px solid var(--gold-primary); flex-shrink: 0;">
          <div style="min-width: 0;">
            <strong id="sidebar-user-name" style="color: var(--text-gold); font-size: 0.8rem; display: block; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">Usuario Maestro</strong>
            <div id="sidebar-user-role" style="font-size: 0.65rem; color: var(--text-muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">Administrador Total</div>
          </div>
        </div>
        <button type="button" class="btn btn-outline btn-sm" onclick="Auth.logout()" title="Cerrar Sesión" style="padding: 4px 8px; font-size: 0.72rem; height: 28px; border-color: rgba(255,255,255,0.15);">
          <i class="bi bi-box-arrow-right"></i>
        </button>
      </div>
      <div style="font-size: 0.7rem; color: var(--gold-light); display: flex; justify-content: space-between; align-items: center; padding-top: 4px; border-top: 1px solid var(--border-subtle); cursor: pointer;" onclick="App.openExchangeRateModal()" title="Clic para cambiar cotización">
        <span><i class="bi bi-currency-exchange"></i> <span id="sidebar-exchange-rate-text">1 USD = ₲ 7.500</span></span>
        <span style="font-size: 0.65rem; color: var(--text-muted);">v2.5</span>
      </div>
    </div>
  </aside>

  <!-- Sidebar Backdrop (mobile tap-to-close) -->
  <div id="sidebar-backdrop" onclick="document.querySelector('.sidebar').classList.remove('open'); this.classList.remove('visible');"></div>

  <!-- Main Content Wrapper -->
  <main class="main-wrapper">
    
    <!-- Topbar Header -->
    <header class="topbar">
      <div class="topbar-brand-box">
        <button class="topbar-back-btn" id="btn-topbar-back" onclick="App.goBack()" style="display: none;" title="Atrás">
          <i class="bi bi-arrow-left"></i>
        </button>
        <button class="mobile-menu-toggle" id="btn-mobile-menu">
          <i class="bi bi-list"></i>
        </button>
        <!-- Logo in topbar (visible on mobile) -->
        <img src="assets/img/logo.jpg" alt="MF Barber" class="topbar-logo-img">
        <div class="page-title-box">
          <h1 id="page-title">Turnos</h1>
          <p id="page-subtitle">Agenda de citas del día y reservas</p>
        </div>
      </div>

      <div class="topbar-actions">
        <!-- Currency Switcher Widget (Guaraníes ₲ / Dólares $) -->
        <div class="currency-switcher-widget">
          <button type="button" class="currency-btn active" id="btn-cur-pyg" onclick="App.setCurrency('PYG')" title="Ver precios en Guaraníes">
            <span>₲</span> <span class="cur-text">Gs</span>
          </button>
          <button type="button" class="currency-btn" id="btn-cur-usd" onclick="App.setCurrency('USD')" title="Ver precios en Dólares">
            <span>$</span> <span class="cur-text">USD</span>
          </button>
          <button type="button" class="currency-rate-btn" onclick="App.openExchangeRateModal()" title="Configurar Cotización USD">
            <i class="bi bi-sliders"></i>
          </button>
        </div>

        <div id="app-mode-badge" style="display: none; align-items: center; gap: 6px; font-size: 0.72rem; padding: 4px 10px; border-radius: 12px; background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.4); color: #34d399; font-weight: 600;" title="Operando en Modo Celular (Sin PC y Sin Internet)">
          <i class="bi bi-lightning-charge-fill"></i>
          <span>Modo Celular</span>
        </div>

        <div class="live-clock">
          <span class="live-clock-dot"></span>
          <span id="live-time">CARGANDO...</span>
        </div>

        <!-- Demo Trial Badge (visible when logged in as demo) -->
        <div class="topbar-demo-badge" id="topbar-demo-badge" title="Estás utilizando la versión de demostración">
          <i class="bi bi-hourglass-split text-gold"></i>
          <span id="demo-remaining-time-text">Prueba: 24h restantes</span>
        </div>

        <!-- Master Control Button in Topbar (visible when logged in as master) -->
        <button type="button" class="btn btn-outline-gold btn-sm master-only" onclick="Auth.openMasterControlModal()" title="Control Maestro de Licencia Demo" style="display: none; padding: 4px 10px; font-weight: 700; height: 32px; font-size: 0.78rem;">
          <i class="bi bi-shield-lock-fill"></i> <span class="d-none-mobile">Control Demo</span>
        </button>

        <button class="btn btn-outline-gold btn-sm d-none-mobile" onclick="Appointments.openNewModal()">
          <i class="bi bi-calendar-plus"></i> <span>Nueva Cita</span>
        </button>
        <button class="btn btn-gold btn-sm d-none-mobile" id="topbar-btn-pos" onclick="App.navigate('pos')">
          <i class="bi bi-cash-coin"></i> <span>Abrir Caja</span>
        </button>
      </div>
    </header>

    <!-- Content Views Area -->
    <div class="content-area">

      <!-- ==========================================
           VIEW 0: BIENVENIDA / LANDING (HOME)
           ========================================== -->
      <section id="view-welcome" class="view-section active">
        <!-- Hero Welcome Banner -->
        <div class="welcome-hero-card">
          <div class="welcome-hero-content">
            <div class="welcome-badge">
              <span class="pulse-gold-dot"></span>
              <span>SISTEMA ACTIVO • MF BARBER & LOUNGE</span>
            </div>
            <h1 class="welcome-hero-title">
              ¡Bienvenido al Sistema <span class="text-gold-gradient">MF Barber Shop</span>!
            </h1>
            <p class="welcome-hero-subtitle">
              Plataforma integral de gestión: reserva de turnos, cobranza ágil en caja, catálogo exclusivo de cortes, perfumería decant y bebidas lounge.
            </p>
            <div class="welcome-quick-actions">
              <button class="btn btn-gold" onclick="Appointments.openNewModal()" style="font-weight: 700; height: 42px; padding: 0 16px; border-radius: var(--radius-sm); display: inline-flex; align-items: center; gap: 8px;">
                <i class="bi bi-calendar-plus"></i> Reservar Turno
              </button>
              <button class="btn btn-outline-gold" onclick="App.navigate('pos')" style="font-weight: 700; height: 42px; padding: 0 16px; border-radius: var(--radius-sm); display: inline-flex; align-items: center; gap: 8px;">
                <i class="bi bi-lightning-charge-fill"></i> Abrir Caja (POS)
              </button>
              <button class="btn btn-secondary" onclick="App.navigate('appointments')" style="font-weight: 700; height: 42px; padding: 0 14px; border-radius: var(--radius-sm); display: inline-flex; align-items: center; gap: 8px;">
                <i class="bi bi-calendar-week"></i> Ver Agenda de Hoy
              </button>
            </div>
          </div>
          <div class="welcome-hero-logo-wrap">
            <div class="welcome-logo-glow"></div>
            <img src="assets/img/logo.jpg" alt="MF Barber" class="welcome-hero-logo">
          </div>
        </div>

        <!-- 4 Action Cards Grid (Landing Navigation) -->
        <div class="welcome-modules-grid">
          <!-- Card 1: Turnos -->
          <div class="welcome-module-card" onclick="App.navigate('appointments')">
            <div class="module-card-icon gold">
              <i class="bi bi-calendar-check-fill"></i>
            </div>
            <div class="module-card-body">
              <h3>Agenda de Turnos</h3>
              <p>Control de citas del día, reservas de clientes y lista de espera en tiempo real.</p>
              <div class="module-card-footer">
                <span class="btn-text-gold">Entrar a Turnos <i class="bi bi-arrow-right"></i></span>
              </div>
            </div>
          </div>

          <!-- Card 2: POS / Caja -->
          <div class="welcome-module-card" onclick="App.navigate('pos')">
            <div class="module-card-icon emerald">
              <i class="bi bi-cash-coin"></i>
            </div>
            <div class="module-card-body">
              <h3>Venta Rápida (Caja)</h3>
              <p>Cobro de cortes, fraccionamiento de decants, bebidas y comprobantes inmediatos.</p>
              <div class="module-card-footer">
                <span class="btn-text-gold">Abrir Caja POS <i class="bi bi-arrow-right"></i></span>
              </div>
            </div>
          </div>

          <!-- Card 3: Clientes -->
          <div class="welcome-module-card" onclick="App.navigate('clients')">
            <div class="module-card-icon purple">
              <i class="bi bi-people-fill"></i>
            </div>
            <div class="module-card-body">
              <h3>Fichas de Clientes</h3>
              <p>Base de datos de clientes frecuentes, notas de estilo, teléfonos y cobro directo.</p>
              <div class="module-card-footer">
                <span class="btn-text-gold">Ver Clientes <i class="bi bi-arrow-right"></i></span>
              </div>
            </div>
          </div>

          <!-- Card 4: Inventario -->
          <div class="welcome-module-card" onclick="App.navigate('inventory')">
            <div class="module-card-icon sky">
              <i class="bi bi-box-seam-fill"></i>
            </div>
            <div class="module-card-body">
              <h3>Stock & Perfumería</h3>
              <p>Inventario de perfumes, frascos decants por ml, botellas y bebidas lounge.</p>
              <div class="module-card-footer">
                <span class="btn-text-gold">Ver Inventario <i class="bi bi-arrow-right"></i></span>
              </div>
            </div>
          </div>
        </div>

        <!-- Metric Cards Resumen del Día -->
        <div class="grid-4" style="margin-bottom: 24px;">
          <div class="stat-card">
            <div class="stat-icon gold">
              <i class="bi bi-cash-stack"></i>
            </div>
            <div class="stat-info">
              <div class="stat-label">Ingresos de Hoy</div>
              <div class="stat-value" id="welcome-revenue-today">$ 0</div>
              <div class="stat-desc" id="welcome-sales-count-today">0 ventas hoy</div>
            </div>
          </div>

          <div class="stat-card">
            <div class="stat-icon sky">
              <i class="bi bi-calendar-check-fill"></i>
            </div>
            <div class="stat-info">
              <div class="stat-label">Turnos de Hoy</div>
              <div class="stat-value" id="welcome-appointments-today">0</div>
              <div class="stat-desc">Citas programadas</div>
            </div>
          </div>

          <div class="stat-card">
            <div class="stat-icon emerald">
              <i class="bi bi-graph-up-arrow"></i>
            </div>
            <div class="stat-info">
              <div class="stat-label">Recaudación Mes</div>
              <div class="stat-value" id="welcome-revenue-month">$ 0</div>
              <div class="stat-desc" id="welcome-sales-month-count">Mes actual</div>
            </div>
          </div>

          <div class="stat-card">
            <div class="stat-icon purple">
              <i class="bi bi-person-check-fill"></i>
            </div>
            <div class="stat-info">
              <div class="stat-label">Total Clientes</div>
              <div class="stat-value" id="welcome-clients-count">0</div>
              <div class="stat-desc">Registrados</div>
            </div>
          </div>
        </div>

        <!-- Citas de Hoy Widget -->
        <div class="card card-gold-accent" style="margin-bottom: 24px;">
          <div class="card-header">
            <div class="card-title">
              <i class="bi bi-clock-history"></i> Turnos Programados para Hoy
            </div>
            <div style="display: flex; gap: 8px;">
              <button class="btn btn-outline btn-sm" onclick="App.navigate('appointments')">
                Ver Agenda Completa <i class="bi bi-arrow-right"></i>
              </button>
              <button class="btn btn-gold btn-sm" onclick="Appointments.openNewModal()">
                <i class="bi bi-plus-lg"></i> Agendar Cita
              </button>
            </div>
          </div>
          <div id="welcome-today-appointments-list">
            <!-- Rendered by JS -->
          </div>
        </div>
      </section>

      <!-- ==========================================
           VIEW 1: DASHBOARD
           ========================================== -->
      <section id="view-dashboard" class="view-section">
        <!-- Metric Cards -->
        <div class="grid-4" style="margin-bottom: 20px;">
          <div class="stat-card">
            <div class="stat-icon gold">
              <i class="bi bi-cash-stack"></i>
            </div>
            <div class="stat-info">
              <div class="stat-label">Ingresos Hoy</div>
              <div class="stat-value" id="dash-revenue-today">$ 0</div>
              <div class="stat-desc" id="dash-sales-count-today">0 ventas hoy</div>
            </div>
          </div>

          <div class="stat-card">
            <div class="stat-icon sky">
              <i class="bi bi-calendar-check-fill"></i>
            </div>
            <div class="stat-info">
              <div class="stat-label">Turnos Hoy</div>
              <div class="stat-value" id="dash-appointments-today">0</div>
              <div class="stat-desc">Turnos agendados</div>
            </div>
          </div>

          <div class="stat-card">
            <div class="stat-icon emerald">
              <i class="bi bi-graph-up-arrow"></i>
            </div>
            <div class="stat-info">
              <div class="stat-label">Ingresos Mes</div>
              <div class="stat-value" id="dash-revenue-month">$ 0</div>
              <div class="stat-desc" id="dash-sales-month-count">Mes en curso</div>
            </div>
          </div>

          <div class="stat-card">
            <div class="stat-icon purple">
              <i class="bi bi-people-fill"></i>
            </div>
            <div class="stat-info">
              <div class="stat-label">Clientes</div>
              <div class="stat-value" id="dash-clients-count">0</div>
              <div class="stat-desc">Base de datos</div>
            </div>
          </div>
        </div>

        <!-- Appointments of Today -->
        <div class="card card-gold-accent" style="margin-bottom: 24px;">
          <div class="card-header">
            <div class="card-title">
              <i class="bi bi-clock-history"></i> Turnos y Citas de Hoy
            </div>
            <div style="display: flex; gap: 10px;">
              <button class="btn btn-outline btn-sm" onclick="App.navigate('appointments')">
                Ver Agenda Completa <i class="bi bi-arrow-right"></i>
              </button>
              <button class="btn btn-gold btn-sm" onclick="Appointments.openNewModal()">
                <i class="bi bi-plus-lg"></i> Agendar
              </button>
            </div>
          </div>
          <div id="dash-today-appointments-list">
            <!-- Rendered by JS -->
          </div>
        </div>

        <!-- Charts & Category Breakdown -->
        <div class="grid-2" style="margin-bottom: 24px;">
          <div class="card">
            <div class="card-header">
              <div class="card-title">
                <i class="bi bi-pie-chart-fill"></i> Ventas por Categoría
              </div>
              <span class="badge badge-gold">Servicios & Extras</span>
            </div>
            <div id="dash-category-breakdown">
              <!-- Rendered by JS -->
            </div>
          </div>

          <div class="card">
            <div class="card-header">
              <div class="card-title">
                <i class="bi bi-bar-chart-fill"></i> Tendencia de Facturación (Últimos 7 días)
              </div>
              <span class="badge badge-emerald">En vivo</span>
            </div>
            <div id="dash-revenue-trend-chart">
              <!-- Rendered by JS -->
            </div>
          </div>
        </div>

        <!-- Low Stock Alerts -->
        <div class="card">
          <div class="card-header">
            <div class="card-title">
              <i class="bi bi-exclamation-triangle-fill text-rose"></i> Alerta de Stock Bajo (Perfumes Decants & Bebidas)
            </div>
            <button class="btn btn-outline btn-sm" onclick="App.navigate('inventory')">
              Ver Inventario <i class="bi bi-arrow-right"></i>
            </button>
          </div>
          <div id="dash-low-stock-list">
            <!-- Rendered by JS -->
          </div>
        </div>
      </section>

      <!-- ==========================================
           VIEW 2: APPOINTMENTS / RESERVAS
           ========================================== -->
      <section id="view-appointments" class="view-section">
        <div class="card" style="margin-bottom: 14px; padding: 14px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; flex-wrap: wrap; gap: 8px;">
            <div>
              <div style="font-weight: 800; font-size: 1.05rem; color: #fff; display: flex; align-items: center; gap: 8px;">
                <i class="bi bi-calendar2-check-fill text-gold"></i> Agenda & Turnos
              </div>
              <div style="font-size: 0.78rem; color: var(--text-muted);">Tolerancia de 5 min tras la hora agendada</div>
            </div>
            <button class="btn btn-gold btn-sm" onclick="Appointments.openNewModal()" style="font-weight: 700; padding: 8px 14px;">
              <i class="bi bi-calendar-plus"></i> <span>+ Agendar Turno</span>
            </button>
          </div>

          <div style="display: flex; flex-direction: column; gap: 10px;">
            <div style="display: flex; justify-content: space-between; align-items: center; gap: 8px;">
              <div style="display: flex; gap: 4px; flex: 1;">
                <button class="btn btn-secondary btn-sm active" id="btn-filter-today" onclick="Appointments.setFilterDate('today')" style="flex: 1; padding: 6px 4px;">Hoy</button>
                <button class="btn btn-secondary btn-sm" onclick="Appointments.setFilterDate('tomorrow')" style="flex: 1; padding: 6px 4px;">Mañana</button>
                <button class="btn btn-secondary btn-sm" onclick="Appointments.setFilterDate('all')" style="flex: 1; padding: 6px 4px;">Todos</button>
              </div>
              <input type="date" id="appointment-filter-date" class="form-control" style="width: 130px; padding: 6px 8px; font-size: 0.8rem;">
            </div>

            <div class="filter-tabs" style="margin-bottom: 0;">
              <button class="tab-btn app-status-filter-btn active" data-status="all">Todos</button>
              <button class="tab-btn app-status-filter-btn" data-status="Confirmada">✅ Confirmadas</button>
              <button class="tab-btn app-status-filter-btn" data-status="Cancelada">❌ Canceladas</button>
            </div>
          </div>
        </div>

        <div id="appointments-list-container">
          <!-- Rendered by JS -->
        </div>

        <!-- Floating Action Button for Appointments -->
        <button class="mobile-fab" onclick="Appointments.openNewModal()" title="Agendar Turno">
          <i class="bi bi-calendar-plus"></i>
        </button>
      </section>

      <!-- ==========================================
           VIEW 3: CLIENTS / CRM
           ========================================== -->
      <section id="view-clients" class="view-section">
        <div class="card" style="margin-bottom: 16px;">
          <div style="display: flex; justify-content: space-between; align-items: center; gap: 10px;">
            <div class="search-box" style="flex: 1;">
              <i class="bi bi-search"></i>
              <input type="text" id="client-search-input" class="form-control" placeholder="Buscar cliente por nombre o tel...">
            </div>
            <button class="btn btn-gold" onclick="Clients.openNewModal()" style="white-space: nowrap;">
              <i class="bi bi-person-plus-fill"></i> <span class="d-none-mobile">Nuevo Cliente</span>
            </button>
          </div>
        </div>

        <div id="clients-list-container">
          <!-- Rendered by JS -->
        </div>

        <!-- Floating Action Button for Clients -->
        <button class="mobile-fab" onclick="Clients.openNewModal()" title="Registrar Cliente">
          <i class="bi bi-person-plus-fill"></i>
        </button>
      </section>

      <!-- ==========================================
           VIEW 4: SERVICES / CORTES
           ========================================== -->
      <section id="view-services" class="view-section">
        <div class="card" style="margin-bottom: 20px;">
          <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
            <div>
              <h3 style="color: #fff; margin-bottom: 2px;">Catálogo de Cortes & Servicios</h3>
              <p style="color: var(--text-muted); font-size: 0.85rem;">Define las tarifas, duraciones y tipos de corte de la barbería</p>
            </div>
            <button class="btn btn-gold" onclick="Services.openNewModal()">
              <i class="bi bi-plus-circle-fill"></i> Nuevo Corte / Servicio
            </button>
          </div>
        </div>

        <div id="services-list-container">
          <!-- Rendered by JS -->
        </div>

        <!-- Floating Action Button for Services -->
        <button class="mobile-fab" onclick="Services.openNewModal()" title="Nuevo Servicio">
          <i class="bi bi-plus-lg"></i>
        </button>
      </section>

      <!-- ==========================================
           VIEW 5: INVENTORY / EXTRAS
           ========================================== -->
      <section id="view-inventory" class="view-section">
        <div class="card" style="margin-bottom: 16px;">
          <div style="display: flex; flex-direction: column; gap: 12px;">
            <div style="display: flex; justify-content: space-between; align-items: center; gap: 10px;">
              <div class="search-box" style="flex: 1;">
                <i class="bi bi-search"></i>
                <input type="text" id="inv-search-input" class="form-control" placeholder="Buscar perfume, decant, bebida...">
              </div>
              <button class="btn btn-gold" onclick="Inventory.openNewModal()" style="white-space: nowrap;">
                <i class="bi bi-plus-lg"></i> <span class="d-none-mobile">Nuevo Producto</span>
              </button>
            </div>

            <!-- Categories Tabs -->
            <div class="filter-tabs" style="margin-bottom: 0;">
              <button class="tab-btn inv-filter-btn active" data-category="all">
                <i class="bi bi-grid"></i> Todos
              </button>
              <button class="tab-btn inv-filter-btn" data-category="decant">
                <i class="bi bi-droplet-half"></i> Decants (5/10ml)
              </button>
              <button class="tab-btn inv-filter-btn" data-category="perfume">
                <i class="bi bi-gem"></i> Perfumes Enteros
              </button>
              <button class="tab-btn inv-filter-btn" data-category="alcohol">
                <i class="bi bi-cup-straw"></i> Alcohol / Cerveza
              </button>
              <button class="tab-btn inv-filter-btn" data-category="no_alcohol">
                <i class="bi bi-cup-hot"></i> Gaseosas & Agua
              </button>
              <button class="tab-btn inv-filter-btn" data-category="low_stock">
                <i class="bi bi-exclamation-circle text-rose"></i> Bajo Stock
              </button>
            </div>
          </div>
        </div>

        <div id="inventory-list-container">
          <!-- Rendered by JS -->
        </div>

        <!-- Floating Action Button for Mobile -->
        <button class="mobile-fab" onclick="Inventory.openNewModal()" title="Agregar Producto">
          <i class="bi bi-plus-lg"></i>
        </button>
      </section>

      <!-- ==========================================
           VIEW 6: POINT OF SALE (POS) / CAJA
           ========================================== -->
      <section id="view-pos" class="view-section">
        <!-- Mobile View Toggle (Catalog vs Cart) -->
        <div class="pos-mobile-toggle-bar">
          <button class="btn btn-gold btn-sm pos-mobile-toggle-btn active" id="pos-btn-show-catalog" onclick="POS.showMobileView('catalog')">
            <i class="bi bi-grid-fill"></i> Catálogo de Productos
          </button>
          <button class="btn btn-secondary btn-sm pos-mobile-toggle-btn" id="pos-btn-show-cart" onclick="POS.showMobileView('cart')">
            <i class="bi bi-cart3"></i> Ver Carrito <span class="badge badge-gold" id="pos-cart-count-badge" style="display: none;">0</span>
          </button>
        </div>

        <div class="pos-container">
          
          <!-- Catalog Panel (Left) -->
          <div id="pos-panel-catalog">
            
            <!-- Quick Client Assignment Bar -->
            <div class="pos-quick-client-bar" style="background: var(--bg-card); border: 1px solid var(--border-gold); border-radius: var(--radius-md); padding: 10px 14px; margin-bottom: 12px; display: flex; align-items: center; justify-content: space-between; gap: 10px; flex-wrap: wrap;">
              <div class="pos-client-main-row" style="display: flex; align-items: center; gap: 10px; flex: 1; min-width: 220px;">
                <div style="width: 36px; height: 36px; border-radius: 50%; background: rgba(212,175,55,0.15); display: flex; align-items: center; justify-content: center; color: var(--gold-light); font-size: 1.15rem; flex-shrink: 0;">
                  <i class="bi bi-person-check-fill"></i>
                </div>
                <div style="flex: 1;">
                  <div style="font-size: 0.72rem; color: var(--text-muted); text-transform: uppercase; font-weight: 700; letter-spacing: 0.04em;">Cliente para este Ticket:</div>
                  <select id="pos-client-select-main" class="form-control" style="padding: 4px 8px; font-size: 0.88rem; font-weight: 700; height: 36px; color: #fff; background: var(--bg-input); border-color: var(--border-subtle);" onchange="POS.syncClientSelect(this.value)">
                    <option value="">-- Venta Casual / Mostrador (Sin cliente) --</option>
                  </select>
                </div>
              </div>
              <button type="button" class="btn btn-outline-gold btn-sm btn-add-client" onclick="POS.openQuickAddClient()" style="font-weight: 700; height: 36px; padding: 0 12px; display: inline-flex; align-items: center; gap: 6px; border-radius: var(--radius-sm);">
                <i class="bi bi-person-plus-fill"></i> + Registrar Cliente
              </button>
            </div>

            <div class="card" style="margin-bottom: 14px; padding: 12px 14px;">
              <div style="display: flex; gap: 8px; margin-bottom: 10px; align-items: center; flex-wrap: wrap;">
                <div class="search-box" style="flex: 1; min-width: 180px;">
                  <i class="bi bi-search"></i>
                  <input type="text" id="pos-search-input" class="form-control" placeholder="Buscar corte, perfume decant o bebida...">
                </div>
                <div style="display: flex; gap: 6px;">
                  <button type="button" class="btn btn-gold btn-sm" onclick="Services.openNewModal()" title="Agregar nuevo corte al catálogo" style="white-space: nowrap; height: 42px; display: inline-flex; align-items: center; gap: 6px; padding: 0 12px; font-weight: 700; border-radius: var(--radius-sm);">
                    <i class="bi bi-scissors"></i> <span>+ Corte</span>
                  </button>
                  <button type="button" class="btn btn-secondary btn-sm" onclick="Inventory.openNewModal()" title="Agregar nuevo perfume o bebida" style="white-space: nowrap; height: 42px; display: inline-flex; align-items: center; gap: 6px; padding: 0 12px; font-weight: 700; border-radius: var(--radius-sm);">
                    <i class="bi bi-box-seam"></i> <span>+ Producto</span>
                  </button>
                </div>
              </div>

              <div class="filter-tabs" style="margin-bottom: 0;">
                <button class="tab-btn pos-tab-btn active" data-tab="all">Todos</button>
                <button class="tab-btn pos-tab-btn" data-tab="services">💈 Cortes</button>
                <button class="tab-btn pos-tab-btn" data-tab="decant">💧 Decants</button>
                <button class="tab-btn pos-tab-btn" data-tab="perfume">✨ Perfumes</button>
                <button class="tab-btn pos-tab-btn" data-tab="alcohol">🍺 Cerveza</button>
                <button class="tab-btn pos-tab-btn" data-tab="no_alcohol">🥤 Gaseosas</button>
              </div>
            </div>

            <!-- Items Catalog Grid -->
            <div class="pos-catalog-grid" id="pos-catalog-grid">
              <!-- Rendered by JS -->
            </div>
          </div>

          <!-- Live Cart & Checkout Drawer (Right) -->
          <div class="pos-cart-panel card-gold-accent" id="pos-panel-cart">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px;">
              <h3 style="color: #fff; font-size: 1.15rem; display: flex; align-items: center; gap: 8px;">
                <i class="bi bi-cart3 text-gold"></i> Ticket Actual
              </h3>
              <button class="btn btn-outline btn-sm" onclick="POS.clearCart()" title="Limpiar Carrito">
                <i class="bi bi-trash"></i> Vaciar
              </button>
            </div>

            <!-- Client Selection & Quick Add Button -->
            <div class="form-group" style="margin-bottom: 12px;">
              <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                <label style="margin-bottom: 0; font-size: 0.82rem; color: var(--text-secondary);"><i class="bi bi-person-fill text-gold"></i> Cliente Asignado:</label>
                <button type="button" class="btn btn-outline-gold btn-sm" onclick="POS.openQuickAddClient()" style="padding: 3px 9px; font-size: 0.72rem; min-height: 26px; border-radius: 6px;">
                  <i class="bi bi-person-plus-fill"></i> + Nuevo Cliente
                </button>
              </div>
              <select id="pos-client-select" class="form-control">
                <option value="">-- Venta Rápida (Mostrador / Ocasional) --</option>
              </select>
            </div>

            <!-- Cart Items List -->
            <div class="pos-cart-items" id="pos-cart-items-container">
              <!-- Rendered by JS -->
            </div>

            <!-- Payment & Totals -->
            <div style="margin-top: 14px;">
              <div class="cart-total-row">
                <span style="color: var(--text-secondary);">Subtotal:</span>
                <span style="font-family: var(--font-mono); font-weight: 700; color: #fff;" id="pos-summary-subtotal">$ 0</span>
              </div>

              <div class="cart-total-row" style="align-items: center;">
                <span style="color: var(--text-secondary);">Descuento (Gs.):</span>
                <input type="number" id="pos-discount-input" class="form-control" style="width: 110px; padding: 4px 8px; text-align: right;" value="0" min="0" step="500">
              </div>

              <div class="cart-total-row grand-total">
                <span>TOTAL A COBRAR:</span>
                <span id="pos-summary-total">₲ 0</span>
              </div>

              <!-- Payment Method -->
              <div class="form-group" style="margin-top: 14px; margin-bottom: 10px;">
                <label><i class="bi bi-credit-card"></i> Método de Pago:</label>
                <select id="pos-payment-method" class="form-control" style="font-weight: 700;">
                  <option value="Efectivo">💵 Efectivo</option>
                  <option value="Tarjeta">💳 Cobro en POS (Tarjeta)</option>
                  <option value="Transferencia">📲 Transferencia / QR</option>
                </select>
              </div>

              <!-- Cash Calculator -->
              <div id="pos-cash-calculator-box" style="background: var(--bg-input); padding: 12px; border-radius: var(--radius-sm); margin-bottom: 12px; border: 1px solid var(--border-subtle);">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; gap: 8px;">
                  <span style="font-size: 0.82rem; color: var(--text-secondary); white-space: nowrap;"><i class="bi bi-currency-exchange"></i> Moneda del Pago:</span>
                  <select id="pos-pay-currency" class="form-control" style="width: auto; padding: 4px 8px; font-size: 0.82rem; font-weight: 700;">
                    <option value="PYG">🇵🇾 Guaraníes (₲)</option>
                    <option value="USD">🇺🇸 Dólares ($)</option>
                  </select>
                </div>
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                  <span style="font-size: 0.82rem; color: var(--text-secondary);">Cliente paga con:</span>
                  <input type="number" id="pos-amount-paid" class="form-control" style="width: 140px; padding: 4px 8px; text-align: right;" placeholder="0">
                </div>
                <div style="display: flex; justify-content: space-between; align-items: center; font-size: 1rem; font-weight: 800;">
                  <span style="color: var(--emerald);"><i class="bi bi-arrow-return-left"></i> Vuelto:</span>
                  <span style="font-family: var(--font-mono); color: var(--emerald); font-size: 1.05rem;" id="pos-summary-change">₲ 0</span>
                </div>
              </div>

              <div class="form-group" style="margin-bottom: 14px;">
                <input type="text" id="pos-notes-input" class="form-control" placeholder="Observaciones / Nota en ticket (opcional)">
              </div>

              <button class="btn btn-gold" id="btn-pos-checkout" style="width: 100%; padding: 14px; font-size: 1.05rem;" onclick="POS.processCheckout()">
                <i class="bi bi-check2-circle"></i> Confirmar y Cobrar
              </button>

              <button type="button" class="btn btn-outline btn-sm" style="width: 100%; margin-top: 10px; font-size: 0.82rem; border-color: rgba(255,255,255,0.12);" onclick="App.navigate('sales')">
                <i class="bi bi-receipt-cutoff text-gold"></i> Ver Historial y Reportes de Caja
              </button>
            </div>
          </div>

        </div>
      </section>

      <!-- ==========================================
           VIEW 7: SALES HISTORY
           ========================================== -->
      <section id="view-sales" class="view-section">
        <!-- Resumen Detallado por Medio de Pago (Efectivo, Cobro en POS, Transferencia) -->
        <div class="sales-breakdown-grid" id="sales-breakdown-container">
          <!-- Rendered by JS -->
        </div>

        <div class="card" style="margin-bottom: 20px;">
          <!-- Filtro de Período Rápido -->
          <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; margin-bottom: 14px; padding-bottom: 12px; border-bottom: 1px solid var(--border-subtle);">
            <div style="display: flex; align-items: center; gap: 6px;">
              <i class="bi bi-funnel text-gold"></i>
              <span style="font-size: 0.82rem; font-weight: 700; color: var(--text-secondary); text-transform: uppercase;">Período:</span>
            </div>
            <div style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
              <div class="filter-tabs" id="sales-period-tabs" style="margin-bottom: 0;">
                <button type="button" class="tab-btn active" data-period="all" onclick="Sales.setPeriod('all')">Todo</button>
                <button type="button" class="tab-btn" data-period="today" onclick="Sales.setPeriod('today')"><i class="bi bi-calendar-event"></i> Hoy</button>
                <button type="button" class="tab-btn" data-period="week" onclick="Sales.setPeriod('week')">Esta Semana</button>
                <button type="button" class="tab-btn" data-period="month" onclick="Sales.setPeriod('month')">Este Mes</button>
              </div>
              <button type="button" class="btn btn-gold btn-sm" onclick="Sales.openDailyClosingModal()" style="display: inline-flex; align-items: center; gap: 6px; font-weight: 700;">
                <i class="bi bi-safe-fill"></i> <span>Arqueo / Cierre de Caja</span>
              </button>
            </div>
          </div>

          <!-- Búsqueda y Selector de Medio de Pago -->
          <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
            <div class="search-box" style="flex: 1; min-width: 240px;">
              <i class="bi bi-search"></i>
              <input type="text" id="sales-search-input" class="form-control" placeholder="Buscar por cliente, n° ticket o detalle...">
            </div>

            <div style="display: flex; gap: 8px; align-items: center;">
              <label style="font-size: 0.85rem; color: var(--text-secondary); white-space: nowrap;">Filtrar Medio:</label>
              <select id="sales-filter-payment" class="form-control" style="width: auto; font-weight: 700;">
                <option value="all">Todos los Medios</option>
                <option value="Efectivo">💵 Efectivo</option>
                <option value="Tarjeta">💳 Cobro en POS</option>
                <option value="Transferencia">📲 Transferencia</option>
              </select>
            </div>
          </div>

          <!-- Filtro por Tipo de Venta (Clientes con Ficha vs Venta Mostrador) -->
          <div style="display: flex; gap: 8px; align-items: center; margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--border-subtle); flex-wrap: wrap;">
            <div style="display: flex; align-items: center; gap: 6px;">
              <i class="bi bi-people-fill text-gold"></i>
              <span style="font-size: 0.82rem; font-weight: 700; color: var(--text-secondary); text-transform: uppercase;">Tipo de Venta:</span>
            </div>
            <div class="filter-tabs" id="sales-client-type-tabs" style="margin-bottom: 0;">
              <button type="button" class="tab-btn active" data-client-type="all" onclick="Sales.setClientType('all')">Todas las Ventas</button>
              <button type="button" class="tab-btn" data-client-type="registered" onclick="Sales.setClientType('registered')"><i class="bi bi-person-check-fill"></i> Clientes Registrados</button>
              <button type="button" class="tab-btn" data-client-type="counter" onclick="Sales.setClientType('counter')"><i class="bi bi-lightning-fill"></i> Venta Mostrador (Sin Cliente)</button>
            </div>
          </div>
        </div>

        <div id="sales-list-container">
          <!-- Rendered by JS -->
        </div>
      </section>

    </div>
  </main>
</div>

<!-- ==========================================
     MODALS SECTION
     ========================================== -->

<!-- Modal: New Appointment (Ultra Simple) -->
<div class="modal-overlay" id="modal-new-appointment">
  <div class="modal-box" style="max-width: 460px;">
    <div class="modal-header">
      <h3><i class="bi bi-calendar-plus text-gold"></i> Agendar Turno</h3>
      <button class="modal-close-btn">&times;</button>
    </div>
    <form id="app-modal-form" onsubmit="Appointments.saveAppointment(event)">
      <div class="modal-body" style="padding: 18px 16px;">
        
        <!-- Cliente Selection / Quick Creation -->
        <div class="form-group" style="margin-bottom: 16px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
            <label style="margin-bottom: 0; font-weight: 700; color: #fff;"><i class="bi bi-person-fill text-gold"></i> ¿Para qué Cliente es el Turno? *</label>
            <button type="button" class="btn btn-outline-gold btn-sm" onclick="Appointments.toggleNewClientInput()" id="btn-toggle-app-new-client" style="font-size: 0.72rem; padding: 2px 8px;">
              <i class="bi bi-person-plus-fill"></i> + Nuevo Cliente
            </button>
          </div>
          
          <!-- Existing Client Dropdown -->
          <div id="app-modal-client-select-wrap">
            <select id="app-modal-client" class="form-control" style="font-size: 0.92rem; font-weight: 600;">
              <!-- Rendered by JS -->
            </select>
          </div>

          <!-- Quick Inline New Client Inputs (Hidden by default) -->
          <div id="app-modal-new-client-wrap" style="display: none; background: var(--bg-input); padding: 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-gold); margin-top: 6px;">
            <div class="form-group" style="margin-bottom: 8px;">
              <label style="font-size: 0.75rem;">Nombre Completo *</label>
              <input type="text" id="app-modal-quick-name" class="form-control" placeholder="Ej: Lucas Martínez" style="font-size: 0.88rem;">
            </div>
            <div class="form-group" style="margin-bottom: 0;">
              <label style="font-size: 0.75rem;">Teléfono / WhatsApp *</label>
              <input type="tel" id="app-modal-quick-phone" class="form-control" placeholder="Ej: 0981 123456" style="font-size: 0.88rem;">
            </div>
          </div>
        </div>

        <!-- Fecha del Turno -->
        <div class="form-group" style="margin-bottom: 16px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
            <label style="margin-bottom: 0; font-weight: 700; color: #fff;"><i class="bi bi-calendar-event text-gold"></i> Fecha del Turno *</label>
            <div style="display: flex; gap: 4px;">
              <button type="button" class="btn btn-secondary btn-sm" style="font-size: 0.72rem; padding: 2px 7px;" onclick="Appointments.setModalDate('today')">Hoy</button>
              <button type="button" class="btn btn-secondary btn-sm" style="font-size: 0.72rem; padding: 2px 7px;" onclick="Appointments.setModalDate('tomorrow')">Mañana</button>
            </div>
          </div>
          <input type="date" id="app-modal-date" class="form-control" required style="font-size: 0.95rem; font-weight: 600;">
        </div>

        <!-- Hora del Turno -->
        <div class="form-group" style="margin-bottom: 16px;">
          <label style="font-weight: 700; color: #fff; margin-bottom: 6px;"><i class="bi bi-clock text-gold"></i> Hora de la Cita *</label>
          <input type="time" id="app-modal-time" class="form-control" required style="font-size: 1.1rem; font-weight: 800; text-align: center; letter-spacing: 0.05em;">
          
          <!-- Quick time chips -->
          <div style="display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px;">
            <button type="button" class="btn btn-secondary btn-sm" style="font-size: 0.75rem; padding: 3px 8px;" onclick="document.getElementById('app-modal-time').value='09:00'">09:00</button>
            <button type="button" class="btn btn-secondary btn-sm" style="font-size: 0.75rem; padding: 3px 8px;" onclick="document.getElementById('app-modal-time').value='10:00'">10:00</button>
            <button type="button" class="btn btn-secondary btn-sm" style="font-size: 0.75rem; padding: 3px 8px;" onclick="document.getElementById('app-modal-time').value='11:00'">11:00</button>
            <button type="button" class="btn btn-secondary btn-sm" style="font-size: 0.75rem; padding: 3px 8px;" onclick="document.getElementById('app-modal-time').value='14:00'">14:00</button>
            <button type="button" class="btn btn-secondary btn-sm" style="font-size: 0.75rem; padding: 3px 8px;" onclick="document.getElementById('app-modal-time').value='15:30'">15:30</button>
            <button type="button" class="btn btn-secondary btn-sm" style="font-size: 0.75rem; padding: 3px 8px;" onclick="document.getElementById('app-modal-time').value='17:00'">17:00</button>
            <button type="button" class="btn btn-secondary btn-sm" style="font-size: 0.75rem; padding: 3px 8px;" onclick="document.getElementById('app-modal-time').value='18:30'">18:30</button>
            <button type="button" class="btn btn-secondary btn-sm" style="font-size: 0.75rem; padding: 3px 8px;" onclick="document.getElementById('app-modal-time').value='20:00'">20:00</button>
          </div>
        </div>

        <div style="background: rgba(212,175,55,0.08); border: 1px solid rgba(212,175,55,0.25); border-radius: var(--radius-sm); padding: 10px 12px; font-size: 0.78rem; color: var(--gold-light); line-height: 1.4;">
          <i class="bi bi-info-circle-fill"></i> <strong>Nota:</strong> Los cortes y consumiciones (bebidas, perfumes) se agregan directamente al momento de atender y cobrar en la caja.
        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-modal-cancel">Cancelar</button>
        <button type="submit" class="btn btn-gold" style="font-weight: 700; padding: 10px 20px;"><i class="bi bi-check-lg"></i> Guardar Turno</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal: Client (Add / Edit) -->
<div class="modal-overlay" id="modal-client">
  <div class="modal-box">
    <div class="modal-header">
      <h3 id="client-modal-title"><i class="bi bi-person-plus"></i> Registrar Cliente</h3>
      <button class="modal-close-btn">&times;</button>
    </div>
    <form id="client-modal-form" onsubmit="Clients.saveClient(event)">
      <input type="hidden" id="client-modal-id">
      <div class="modal-body">
        <div class="form-group">
          <label>Nombre y Apellido *</label>
          <input type="text" id="client-modal-name" class="form-control" placeholder="Ej: Lucas Martínez" required>
        </div>

        <div class="form-group">
          <label>Teléfono / WhatsApp * (Con código de país/área)</label>
          <input type="text" id="client-modal-phone" class="form-control" placeholder="Ej: +54 9 11 1234-5678" required>
        </div>

        <div class="form-group">
          <label>Email (Opcional)</label>
          <input type="email" id="client-modal-email" class="form-control" placeholder="cliente@correo.com">
        </div>

        <div class="form-group">
          <label>Notas / Preferencias de Estilo</label>
          <textarea id="client-modal-notes" class="form-control" rows="3" placeholder="Ej: Le gusta fade medio, navaja al ras, fan de los decants amaderados"></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-modal-cancel">Cancelar</button>
        <button type="submit" class="btn btn-gold">Guardar Cliente</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal: Client History Profile -->
<div class="modal-overlay" id="modal-client-history">
  <div class="modal-box modal-lg">
    <div class="modal-header">
      <h3><i class="bi bi-person-badge"></i> Historial y Ficha del Cliente</h3>
      <button class="modal-close-btn">&times;</button>
    </div>
    <div class="modal-body">
      <div style="background: var(--bg-input); padding: 16px; border-radius: var(--radius-md); margin-bottom: 20px; border: 1px solid var(--border-subtle);">
        <h3 id="history-client-name" style="color: #fff; font-size: 1.25rem;">Nombre</h3>
        <div style="color: var(--text-gold); font-size: 0.9rem; margin-top: 2px;"><i class="bi bi-telephone"></i> <span id="history-client-phone"></span></div>
        <div style="color: var(--text-secondary); font-size: 0.85rem; margin-top: 6px;">
          <strong>Notas:</strong> <span id="history-client-notes"></span>
        </div>
      </div>

      <div class="grid-2">
        <div>
          <h4 style="color: #fff; margin-bottom: 10px; font-size: 1rem;"><i class="bi bi-calendar-check text-gold"></i> Últimos Turnos</h4>
          <div id="history-appointments-list" style="max-height: 250px; overflow-y: auto; background: var(--bg-card); border-radius: var(--radius-sm); border: 1px solid var(--border-subtle);">
            <!-- Rendered by JS -->
          </div>
        </div>
        <div>
          <h4 style="color: #fff; margin-bottom: 10px; font-size: 1rem;"><i class="bi bi-bag-check text-gold"></i> Compras & Cobros</h4>
          <div id="history-sales-list" style="max-height: 250px; overflow-y: auto; background: var(--bg-card); border-radius: var(--radius-sm); border: 1px solid var(--border-subtle);">
            <!-- Rendered by JS -->
          </div>
        </div>
      </div>
    </div>
    <div class="modal-footer" style="display: flex; justify-content: space-between; align-items: center; gap: 10px;">
      <button type="button" class="btn btn-gold" id="history-btn-charge"><i class="bi bi-cash-coin"></i> Registrar Cobro / Venta</button>
      <button type="button" class="btn btn-secondary btn-modal-cancel">Cerrar</button>
    </div>
  </div>
</div>

<!-- Modal: Choose Type to Add in POS -->
<div class="modal-overlay" id="modal-pos-new-item">
  <div class="modal-box" style="max-width: 440px;">
    <div class="modal-header">
      <h3 style="display: flex; align-items: center; gap: 8px; font-size: 1.1rem; color: #fff;">
        <i class="bi bi-plus-circle text-gold"></i> Agregar al Catálogo
      </h3>
      <button class="modal-close-btn">&times;</button>
    </div>
    <div class="modal-body" style="padding: 20px 16px;">
      <p style="color: var(--text-secondary); font-size: 0.88rem; margin-bottom: 16px;">
        ¿Qué tipo de artículo deseas registrar en el catálogo?
      </p>
      <div style="display: flex; flex-direction: column; gap: 10px;">
        <button type="button" class="btn btn-secondary" onclick="App.closeModal('modal-pos-new-item'); Services.openNewModal();" style="padding: 14px; display: flex; align-items: center; gap: 12px; font-size: 0.95rem; font-weight: 700; text-align: left; justify-content: flex-start; border-color: rgba(212,175,55,0.4);">
          <i class="bi bi-scissors text-gold" style="font-size: 1.3rem;"></i>
          <div>
            <div style="color: #fff;">Nuevo Servicio / Corte</div>
            <div style="font-size: 0.75rem; color: var(--text-muted); font-weight: normal;">Cortes, perfilado de barba, tratamientos</div>
          </div>
        </button>
        <button type="button" class="btn btn-secondary" onclick="App.closeModal('modal-pos-new-item'); Inventory.openNewModal();" style="padding: 14px; display: flex; align-items: center; gap: 12px; font-size: 0.95rem; font-weight: 700; text-align: left; justify-content: flex-start; border-color: rgba(168,85,247,0.4);">
          <i class="bi bi-box-seam text-purple" style="font-size: 1.3rem;"></i>
          <div>
            <div style="color: #fff;">Nuevo Producto / Extra</div>
            <div style="font-size: 0.75rem; color: var(--text-muted); font-weight: normal;">Decants, perfumes enteros, cervezas, gaseosas</div>
          </div>
        </button>
      </div>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-secondary btn-modal-cancel">Cancelar</button>
    </div>
  </div>
</div>

<!-- Modal: Service (Add / Edit) -->
<div class="modal-overlay" id="modal-service">
  <div class="modal-box">
    <div class="modal-header">
      <h3 id="service-modal-title"><i class="bi bi-scissors text-gold"></i> Registrar / Editar Corte</h3>
      <button class="modal-close-btn">&times;</button>
    </div>
    <form id="service-modal-form" onsubmit="Services.saveService(event)">
      <input type="hidden" id="service-modal-id">
      <div class="modal-body">
        <div class="form-group">
          <label>Nombre del Corte o Servicio *</label>
          <input type="text" id="service-modal-name" class="form-control" placeholder="Ej: Degradé / Fade Pro, Corte Clásico, Barba..." required>
          
          <!-- Quick service name suggestions -->
          <div style="display: flex; flex-wrap: wrap; gap: 6px; margin-top: 6px;">
            <button type="button" class="btn btn-secondary btn-sm" style="font-size: 0.72rem; padding: 3px 7px;" onclick="document.getElementById('service-modal-name').value='Degradé / Fade Pro'; document.getElementById('service-modal-category').value='Corte'; document.getElementById('service-modal-price').value=50000; document.getElementById('service-modal-duration').value=40;">Degradé Fade</button>
            <button type="button" class="btn btn-secondary btn-sm" style="font-size: 0.72rem; padding: 3px 7px;" onclick="document.getElementById('service-modal-name').value='Corte Clásico a Tijera'; document.getElementById('service-modal-category').value='Corte'; document.getElementById('service-modal-price').value=35000; document.getElementById('service-modal-duration').value=30;">Corte Clásico</button>
            <button type="button" class="btn btn-secondary btn-sm" style="font-size: 0.72rem; padding: 3px 7px;" onclick="document.getElementById('service-modal-name').value='Perfilado de Barba & Toalla'; document.getElementById('service-modal-category').value='Barba'; document.getElementById('service-modal-price').value=30000; document.getElementById('service-modal-duration').value=25;">Barba & Toalla</button>
            <button type="button" class="btn btn-secondary btn-sm" style="font-size: 0.72rem; padding: 3px 7px;" onclick="document.getElementById('service-modal-name').value='Combo Corte + Barba VIP'; document.getElementById('service-modal-category').value='Combo'; document.getElementById('service-modal-price').value=80000; document.getElementById('service-modal-duration').value=55;">Corte + Barba VIP</button>
            <button type="button" class="btn btn-secondary btn-sm" style="font-size: 0.72rem; padding: 3px 7px;" onclick="document.getElementById('service-modal-name').value='Diseño Freestyle / Líneas'; document.getElementById('service-modal-category').value='Diseño'; document.getElementById('service-modal-price').value=25000; document.getElementById('service-modal-duration').value=20;">Diseño Líneas</button>
            <button type="button" class="btn btn-secondary btn-sm" style="font-size: 0.72rem; padding: 3px 7px;" onclick="document.getElementById('service-modal-name').value='Corte Infantil'; document.getElementById('service-modal-category').value='Corte'; document.getElementById('service-modal-price').value=30000; document.getElementById('service-modal-duration').value=25;">Corte Infantil</button>
          </div>
        </div>

        <div class="grid-2">
          <div class="form-group">
            <label>Categoría *</label>
            <select id="service-modal-category" class="form-control">
              <option value="Corte">💈 Corte de Cabello</option>
              <option value="Barba">🧔 Barba & Afeitado</option>
              <option value="Combo">✂️ Combo Corte + Barba VIP</option>
              <option value="Tratamiento">💆 Tratamiento & Lavado</option>
              <option value="Diseño">🎨 Diseño Freestyle</option>
              <option value="Color">⚡ Tintura / Platinado</option>
            </select>
          </div>
          <div class="form-group">
            <label>Duración Estimada (Minutos) *</label>
            <input type="number" id="service-modal-duration" class="form-control" value="30" min="5" step="5" required>
            <div style="display: flex; gap: 4px; margin-top: 4px;">
              <button type="button" class="btn btn-secondary btn-sm" style="font-size: 0.7rem; padding: 2px 6px; flex: 1;" onclick="document.getElementById('service-modal-duration').value=20">20m</button>
              <button type="button" class="btn btn-secondary btn-sm" style="font-size: 0.7rem; padding: 2px 6px; flex: 1;" onclick="document.getElementById('service-modal-duration').value=30">30m</button>
              <button type="button" class="btn btn-secondary btn-sm" style="font-size: 0.7rem; padding: 2px 6px; flex: 1;" onclick="document.getElementById('service-modal-duration').value=45">45m</button>
              <button type="button" class="btn btn-secondary btn-sm" style="font-size: 0.7rem; padding: 2px 6px; flex: 1;" onclick="document.getElementById('service-modal-duration').value=60">60m</button>
            </div>
          </div>
        </div>

        <div class="form-group">
          <label>Precio del Corte (₲ Guaraníes) *</label>
          <input type="number" id="service-modal-price" class="form-control" placeholder="Ej: 35000 o 50000" min="0" step="500" required>
          
          <!-- Price presets in Guaraníes -->
          <div style="display: flex; flex-wrap: wrap; gap: 4px; margin-top: 6px;">
            <button type="button" class="btn btn-secondary btn-sm" style="font-size: 0.72rem; padding: 3px 6px;" onclick="document.getElementById('service-modal-price').value=25000">₲ 25.000</button>
            <button type="button" class="btn btn-secondary btn-sm" style="font-size: 0.72rem; padding: 3px 6px;" onclick="document.getElementById('service-modal-price').value=30000">₲ 30.000</button>
            <button type="button" class="btn btn-secondary btn-sm" style="font-size: 0.72rem; padding: 3px 6px;" onclick="document.getElementById('service-modal-price').value=35000">₲ 35.000</button>
            <button type="button" class="btn btn-secondary btn-sm" style="font-size: 0.72rem; padding: 3px 6px;" onclick="document.getElementById('service-modal-price').value=40000">₲ 40.000</button>
            <button type="button" class="btn btn-secondary btn-sm" style="font-size: 0.72rem; padding: 3px 6px;" onclick="document.getElementById('service-modal-price').value=50000">₲ 50.000</button>
            <button type="button" class="btn btn-secondary btn-sm" style="font-size: 0.72rem; padding: 3px 6px;" onclick="document.getElementById('service-modal-price').value=80000">₲ 80.000</button>
          </div>
        </div>

        <div class="form-group">
          <label>Descripción / Lo que incluye</label>
          <textarea id="service-modal-description" class="form-control" rows="2" placeholder="Detalles del corte, toalla caliente, navaja, productos usados..."></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-modal-cancel">Cancelar</button>
        <button type="submit" class="btn btn-gold"><i class="bi bi-check-lg"></i> Guardar en Catálogo</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal: Product (Decants, Full Perfumes, Drinks) -->
<div class="modal-overlay" id="modal-product">
  <div class="modal-box">
    <div class="modal-header">
      <h3 id="product-modal-title"><i class="bi bi-box-seam"></i> Producto / Extra</h3>
      <button class="modal-close-btn">&times;</button>
    </div>
    <form id="product-modal-form" onsubmit="Inventory.saveProduct(event)">
      <input type="hidden" id="product-modal-id">
      <div class="modal-body">
        <div class="form-group">
          <label>Nombre del Producto *</label>
          <input type="text" id="product-modal-name" class="form-control" placeholder="Ej: Dior Sauvage EDP (Decant)" required>
        </div>

        <div class="grid-2">
          <div class="form-group">
            <label>Categoría *</label>
            <select id="product-modal-category" class="form-control">
              <option value="decant">💧 Perfume Decant (Fraccionado)</option>
              <option value="perfume">✨ Perfume Entero (Frasco Cerrado)</option>
              <option value="alcohol">🍺 Bebida Alcohólica</option>
              <option value="no_alcohol">🥤 Bebida Sin Alcohol / Agua</option>
              <option value="otro">📦 Otro Producto</option>
            </select>
          </div>
          <div class="form-group">
            <label>Marca / Fabricante</label>
            <input type="text" id="product-modal-brand" class="form-control" placeholder="Ej: Dior, Corona, Coca-Cola">
          </div>
        </div>

        <div class="grid-2">
          <div class="form-group">
            <label>Medida / Volumen</label>
            <input type="text" id="product-modal-size" class="form-control" placeholder="Ej: 5ml, 10ml, 100ml, 355ml">
          </div>
          <div class="form-group">
            <label>Stock Mínimo Alerta</label>
            <input type="number" id="product-modal-min-stock" class="form-control" value="3" min="1">
          </div>
        </div>

        <div class="grid-3">
          <div class="form-group">
            <label>Precio Costo ($)</label>
            <input type="number" id="product-modal-cost" class="form-control" value="0" min="0" step="100">
          </div>
          <div class="form-group">
            <label>Precio Venta ($) *</label>
            <input type="number" id="product-modal-price" class="form-control" placeholder="7500" min="0" step="100" required>
          </div>
          <div class="form-group">
            <label>Stock Inicial *</label>
            <input type="number" id="product-modal-stock" class="form-control" value="10" min="0" required>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-modal-cancel">Cancelar</button>
        <button type="submit" class="btn btn-gold">Guardar Producto</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal: Quick Stock Adjustment -->
<div class="modal-overlay" id="modal-stock-adjust">
  <div class="modal-box">
    <div class="modal-header">
      <h3><i class="bi bi-boxes"></i> Ajustar Stock de Inventario</h3>
      <button class="modal-close-btn">&times;</button>
    </div>
    <form onsubmit="Inventory.applyStockAdjustment(event)">
      <input type="hidden" id="stock-modal-product-id">
      <div class="modal-body">
        <div style="background: var(--bg-input); padding: 14px; border-radius: var(--radius-sm); margin-bottom: 16px; border: 1px solid var(--border-subtle);">
          <strong id="stock-modal-product-name" style="color: #fff; font-size: 1.05rem;">Producto</strong>
          <div style="font-size: 0.85rem; color: var(--text-secondary); margin-top: 4px;">
            Stock actual: <strong id="stock-modal-current" style="color: var(--gold-light);">0</strong>
          </div>
        </div>

        <div class="form-group">
          <label>Operación:</label>
          <select id="stock-modal-mode" class="form-control">
            <option value="add">➕ Agregar Unidades (Llegada de Pedido / Reposición)</option>
            <option value="subtract">➖ Restar Unidades (Merma / Consumo)</option>
            <option value="set">🎯 Establecer Stock Exacto</option>
          </select>
        </div>

        <div class="form-group">
          <label>Cantidad de Unidades:</label>
          <input type="number" id="stock-modal-adjustment" class="form-control" value="5" min="1" required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-modal-cancel">Cancelar</button>
        <button type="submit" class="btn btn-gold">Actualizar Stock</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal: Appointment Booking Confirmation Ticket -->
<div class="modal-overlay" id="modal-appointment-ticket">
  <div class="modal-box" style="background: #101522; max-width: 440px;">
    <div class="modal-header">
      <h3 style="display: flex; align-items: center; gap: 8px; color: #fff;">
        <i class="bi bi-calendar-check text-gold"></i> Comprobante de Turno
      </h3>
      <button class="modal-close-btn">&times;</button>
    </div>
    <div class="modal-body" id="appointment-ticket-content">
      <!-- Rendered by JS -->
    </div>
    <div class="modal-footer" style="justify-content: space-between; flex-wrap: wrap; gap: 8px;">
      <button type="button" class="btn btn-whatsapp" id="btn-app-ticket-whatsapp" onclick="Appointments.shareCurrentTicketWhatsApp()">
        <i class="bi bi-whatsapp"></i> Enviar por WhatsApp
      </button>
      <div style="display: flex; gap: 6px;">
        <button type="button" class="btn btn-secondary" onclick="Appointments.printCurrentAppointmentTicket()">
          <i class="bi bi-printer"></i> Imprimir
        </button>
        <button type="button" class="btn btn-gold btn-modal-cancel">Listo</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal: Printable Receipt Ticket Preview (POS Checkout / Sales) -->
<div class="modal-overlay" id="modal-receipt">
  <div class="modal-box" style="background: #101522; max-width: 440px;">
    <div class="modal-header">
      <h3 style="display: flex; align-items: center; gap: 8px; color: #fff;"><i class="bi bi-receipt text-gold"></i> Comprobante de Cobro / Venta</h3>
      <button class="modal-close-btn">&times;</button>
    </div>
    <div class="modal-body" id="receipt-ticket-content">
      <!-- Rendered by JS -->
    </div>
    <div class="modal-footer" style="justify-content: space-between; flex-wrap: wrap; gap: 8px;">
      <button type="button" class="btn btn-whatsapp" onclick="Sales.sendReceiptWhatsApp()">
        <i class="bi bi-whatsapp"></i> Enviar por WhatsApp
      </button>
      <div style="display: flex; gap: 6px;">
        <button type="button" class="btn btn-danger" id="btn-receipt-cancel-sale" style="display: none;">
          <i class="bi bi-x-octagon"></i> Anular Venta
        </button>
        <button type="button" class="btn btn-secondary" onclick="Sales.printCurrentReceipt()">
          <i class="bi bi-printer"></i> Imprimir
        </button>
        <button type="button" class="btn btn-gold btn-modal-cancel">Cerrar</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal: Currency Exchange Rate Settings -->
<div class="modal-overlay" id="modal-exchange-rate">
  <div class="modal-box" style="max-width: 440px;">
    <div class="modal-header">
      <h3><i class="bi bi-currency-exchange text-gold"></i> Cotización USD / Guaraníes</h3>
      <button class="modal-close-btn">&times;</button>
    </div>
    <form onsubmit="event.preventDefault(); App.setExchangeRate(document.getElementById('modal-rate-input').value);">
      <div class="modal-body">
        <p style="color: var(--text-secondary); font-size: 0.85rem; margin-bottom: 16px;">
          Define la cotización oficial o de mercado para convertir automáticamente entre <strong>Guaraníes (₲)</strong> y <strong>Dólares ($ USD)</strong> en todo el sistema.
        </p>

        <div class="form-group">
          <label>Cotización: 1 Dólar ($ USD) equivale a (₲ Guaraníes) *</label>
          <div style="display: flex; align-items: center; gap: 8px;">
            <span style="font-family: var(--font-mono); font-weight: 700; color: var(--gold-light); font-size: 1.1rem; white-space: nowrap;">1 USD = ₲</span>
            <input type="number" id="modal-rate-input" class="form-control" value="7500" min="1" step="10" required oninput="App.updateRatePreview()" style="font-weight: 700; font-size: 1.1rem; font-family: var(--font-mono);">
          </div>
        </div>

        <!-- Quick Presets -->
        <div style="margin-bottom: 14px;">
          <label style="font-size: 0.78rem; color: var(--text-muted); margin-bottom: 6px; display: block;">Valores rápidos comunes:</label>
          <div style="display: flex; gap: 6px; flex-wrap: wrap;">
            <button type="button" class="btn btn-secondary btn-sm" onclick="document.getElementById('modal-rate-input').value = 7400; App.updateRatePreview();" style="padding: 4px 8px; font-size: 0.75rem;">₲ 7.400</button>
            <button type="button" class="btn btn-secondary btn-sm" onclick="document.getElementById('modal-rate-input').value = 7500; App.updateRatePreview();" style="padding: 4px 8px; font-size: 0.75rem;">₲ 7.500</button>
            <button type="button" class="btn btn-secondary btn-sm" onclick="document.getElementById('modal-rate-input').value = 7600; App.updateRatePreview();" style="padding: 4px 8px; font-size: 0.75rem;">₲ 7.600</button>
            <button type="button" class="btn btn-secondary btn-sm" onclick="document.getElementById('modal-rate-input').value = 7700; App.updateRatePreview();" style="padding: 4px 8px; font-size: 0.75rem;">₲ 7.700</button>
            <button type="button" class="btn btn-secondary btn-sm" onclick="document.getElementById('modal-rate-input').value = 7800; App.updateRatePreview();" style="padding: 4px 8px; font-size: 0.75rem;">₲ 7.800</button>
          </div>
        </div>

        <!-- Live Preview -->
        <div style="background: var(--bg-input); padding: 12px 14px; border-radius: var(--radius-sm); border: 1px solid var(--border-subtle);">
          <div style="font-size: 0.75rem; text-transform: uppercase; color: var(--text-muted); font-weight: 700; letter-spacing: 0.05em; margin-bottom: 4px;">Vista previa de conversión en vivo:</div>
          <div id="rate-preview-calc">
            <!-- Rendered by JS -->
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-modal-cancel">Cancelar</button>
        <button type="submit" class="btn btn-gold"><i class="bi bi-check-lg"></i> Guardar Cotización</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal: Business Settings / Configuración -->
<div class="modal-overlay" id="modal-settings">
  <div class="modal-box" style="max-width: 500px;">
    <div class="modal-header">
      <h3><i class="bi bi-gear-fill text-gold"></i> Configuración del Negocio</h3>
      <button class="modal-close-btn">&times;</button>
    </div>
    <form onsubmit="App.saveSettings(event)">
      <div class="modal-body">
        <p style="color: var(--text-secondary); font-size: 0.85rem; margin-bottom: 16px;">
          Estos datos se imprimen en los tickets térmicos y se utilizan en los comprobantes de WhatsApp.
        </p>
        <div class="form-group">
          <label>Nombre de la Barbería / Negocio *</label>
          <input type="text" id="setting-business-name" class="form-control" required placeholder="Ej: MF Barber & Lounge">
        </div>
        <div class="form-group">
          <label>Teléfono de Contacto (WhatsApp) *</label>
          <input type="text" id="setting-business-phone" class="form-control" placeholder="Ej: +595 993 554920">
        </div>
        <div class="form-group">
          <label>Dirección / Local</label>
          <input type="text" id="setting-business-address" class="form-control" placeholder="Ej: Local Central">
        </div>
        <div class="form-group">
          <label>Mensaje al Pie del Ticket</label>
          <input type="text" id="setting-ticket-footer" class="form-control" placeholder="¡Muchas gracias por su preferencia! 💈✂️">
        </div>
        <div class="form-group">
          <label>Cotización 1 USD en Guaraníes (₲)</label>
          <input type="number" id="setting-exchange-rate" class="form-control" value="7500" min="1" step="10">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-modal-cancel">Cancelar</button>
        <button type="submit" class="btn btn-gold"><i class="bi bi-check-lg"></i> Guardar Cambios</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal: Arqueo y Cierre de Caja Diario -->
<div class="modal-overlay" id="modal-daily-closing">
  <div class="modal-box" style="max-width: 520px;">
    <div class="modal-header">
      <h3><i class="bi bi-safe-fill text-gold"></i> Arqueo &amp; Cierre de Caja</h3>
      <button class="modal-close-btn">&times;</button>
    </div>
    <form onsubmit="Sales.saveDailyClosing(event)">
      <div class="modal-body">
        <div style="display: flex; justify-content: space-between; align-items: center; background: rgba(212, 175, 55, 0.1); border: 1px solid rgba(212, 175, 55, 0.3); border-radius: 8px; padding: 12px 16px; margin-bottom: 16px;">
          <div>
            <span style="font-size: 0.75rem; text-transform: uppercase; color: var(--text-muted); font-weight: 700;">Jornada:</span>
            <div id="closing-date-display" style="font-weight: 800; color: #fff; font-size: 1.05rem;">-</div>
          </div>
          <span class="badge badge-gold" id="closing-sales-count" style="font-size: 0.85rem; padding: 6px 12px;">0 ventas</span>
        </div>

        <!-- Breakdown resumen de ventas del día -->
        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; margin-bottom: 16px; text-align: center;">
          <div style="background: var(--bg-card); padding: 10px; border-radius: 6px; border: 1px solid var(--border-subtle);">
            <div style="font-size: 0.72rem; color: var(--emerald); font-weight: 700;">💵 EFECTIVO</div>
            <div id="closing-cash-sales" style="font-weight: 800; font-family: var(--font-mono); font-size: 0.95rem; margin-top: 4px;">₲ 0</div>
          </div>
          <div style="background: var(--bg-card); padding: 10px; border-radius: 6px; border: 1px solid var(--border-subtle);">
            <div style="font-size: 0.72rem; color: var(--sky); font-weight: 700;">💳 POS / TARJETA</div>
            <div id="closing-card-sales" style="font-weight: 800; font-family: var(--font-mono); font-size: 0.95rem; margin-top: 4px;">₲ 0</div>
          </div>
          <div style="background: var(--bg-card); padding: 10px; border-radius: 6px; border: 1px solid var(--border-subtle);">
            <div style="font-size: 0.72rem; color: var(--purple); font-weight: 700;">📲 TRANSFERENCIA</div>
            <div id="closing-transfer-sales" style="font-weight: 800; font-family: var(--font-mono); font-size: 0.95rem; margin-top: 4px;">₲ 0</div>
          </div>
        </div>

        <div style="display: flex; justify-content: space-between; padding: 8px 12px; background: rgba(255,255,255,0.03); border-radius: 6px; margin-bottom: 16px;">
          <span style="font-size: 0.88rem; font-weight: 700; color: var(--text-secondary);">Total Ventas del Día:</span>
          <span id="closing-total-sales" style="font-weight: 800; font-family: var(--font-mono); color: var(--gold-light); font-size: 1.1rem;">₲ 0</span>
        </div>

        <!-- Form fields for cash counting -->
        <div class="form-group">
          <label>Fondo Inicial de Caja (Monto de apertura en efectivo) ₲</label>
          <input type="number" id="closing-initial-cash" class="form-control" placeholder="0" oninput="Sales.updateClosingCalculations()" style="font-weight: 700; font-family: var(--font-mono);">
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center; padding: 10px 12px; background: rgba(52, 211, 153, 0.08); border: 1px solid rgba(52, 211, 153, 0.2); border-radius: 6px; margin-bottom: 14px;">
          <div>
            <span style="font-size: 0.75rem; text-transform: uppercase; color: var(--text-muted); font-weight: 700;">Efectivo Esperado en Cajón:</span>
            <div style="font-size: 0.72rem; color: var(--text-secondary);">(Fondo Inicial + Ventas Efectivo)</div>
          </div>
          <div id="closing-expected-cash" style="font-size: 1.15rem; font-weight: 800; font-family: var(--font-mono); color: var(--emerald);">₲ 0</div>
        </div>

        <div class="form-group">
          <label>Efectivo Real Contado en Mano (Arqueo físico) ₲ *</label>
          <input type="number" id="closing-actual-cash" class="form-control" placeholder="Ingrese el dinero contado en el cajón" oninput="Sales.updateClosingCalculations()" style="font-weight: 800; font-size: 1.1rem; font-family: var(--font-mono);">
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center; padding: 10px 12px; background: rgba(255,255,255,0.03); border-radius: 6px; margin-bottom: 14px;">
          <span style="font-size: 0.85rem; font-weight: 700; color: var(--text-secondary);">Diferencia de Caja:</span>
          <div id="closing-diff-cash" style="font-size: 0.95rem; font-weight: 700;">Exacto</div>
        </div>

        <div class="form-group" style="margin-bottom: 0;">
          <label>Observaciones del Cierre</label>
          <textarea id="closing-notes" class="form-control" rows="2" placeholder="Notas sobre faltantes, gastos menores o retiros del día..."></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-modal-cancel">Cerrar</button>
        <button type="submit" class="btn btn-gold"><i class="bi bi-safe-fill"></i> Registrar Cierre de Jornada</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal: Login Portal (Master & Demo) -->
<div class="auth-modal-overlay" id="modal-auth-login">
  <div class="auth-card">
    <div class="auth-header">
      <img src="assets/img/logo.jpg" alt="MF Barber" class="auth-logo-img">
      <h2 style="font-family: var(--font-brand); color: #fff; font-size: 1.25rem; margin-bottom: 2px; letter-spacing: 0.05em;">MF BARBER</h2>
      <p style="font-size: 0.74rem; color: var(--gold-primary); text-transform: uppercase; letter-spacing: 0.15em; font-weight: 700; margin: 0;">& LOUNGE SYSTEM</p>
    </div>

    <!-- Tabs: Modo Prueba vs Acceso Maestro -->
    <div class="auth-tabs">
      <button type="button" class="auth-tab-btn active" id="tab-login-demo" onclick="Auth.toggleLoginMode('demo')">
        <i class="bi bi-play-circle-fill text-gold"></i> Probar Demo Gratis
      </button>
      <button type="button" class="auth-tab-btn" id="tab-login-admin" onclick="Auth.toggleLoginMode('admin')">
        <i class="bi bi-shield-lock-fill"></i> Acceso Maestro
      </button>
    </div>

    <div class="auth-body">
      <!-- Demo Card (1-Click for Clients to test!) -->
      <div id="login-card-demo">
        <div style="background: rgba(212, 175, 55, 0.08); border: 1px solid rgba(212, 175, 55, 0.25); border-radius: var(--radius-md); padding: 14px; margin-bottom: 16px; text-align: center;">
          <div style="font-weight: 800; font-size: 0.95rem; color: #fff; margin-bottom: 4px;">¿Quieres conocer la app?</div>
          <p style="font-size: 0.78rem; color: var(--text-secondary); margin: 0; line-height: 1.4;">
            Ingresa al <strong>Modo Demostración</strong> para probar ventas en caja POS, agendar turnos de prueba, gestionar clientes y revisar reportes en tiempo real.
          </p>
        </div>

        <button type="button" class="btn-demo-quick" onclick="Auth.loginAsDemo()">
          <i class="bi bi-lightning-charge-fill"></i> Ingresar a la Demo Ahora
        </button>

        <div style="text-align: center; margin-top: 14px; font-size: 0.72rem; color: var(--text-muted);">
          <i class="bi bi-shield-check text-emerald"></i> Acceso seguro por tiempo limitado regulado por el administrador.
        </div>
      </div>

      <!-- Admin Login Form (For Master User) -->
      <div id="login-card-admin" style="display: none;">
        <form id="auth-login-form">
          <div id="login-error-msg" style="display: none; background: rgba(244, 63, 94, 0.15); border: 1px solid var(--rose); color: #fca5a5; padding: 10px 12px; border-radius: var(--radius-sm); font-size: 0.8rem; margin-bottom: 12px; font-weight: 600;"></div>

          <div class="form-group" style="margin-bottom: 12px;">
            <label style="font-size: 0.82rem; color: var(--text-secondary);"><i class="bi bi-person-fill text-gold"></i> Usuario Maestro:</label>
            <input type="text" id="login-username" class="form-control" value="admin" required placeholder="admin">
          </div>

          <div class="form-group" style="margin-bottom: 16px;">
            <label style="font-size: 0.82rem; color: var(--text-secondary);"><i class="bi bi-key-fill text-gold"></i> Contraseña:</label>
            <input type="password" id="login-password" class="form-control" required placeholder="••••••••">
          </div>

          <button type="submit" class="btn btn-gold" id="btn-login-submit" style="width: 100%; padding: 12px; font-weight: 800; font-size: 0.92rem;">
            <i class="bi bi-box-arrow-in-right"></i> Iniciar Sesión como Maestro
          </button>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Modal: Trial Expired / Deactivated Screen -->
<div class="auth-modal-overlay" id="modal-auth-blocked">
  <div class="auth-card" style="max-width: 420px; text-align: center;">
    <div class="auth-body" style="padding: 28px 20px;">
      <div style="width: 66px; height: 66px; border-radius: 50%; background: rgba(244, 63, 94, 0.15); border: 2px solid var(--rose); color: var(--rose); display: flex; align-items: center; justify-content: center; font-size: 1.85rem; margin: 0 auto 14px; box-shadow: 0 0 24px rgba(244, 63, 94, 0.35);">
        <i class="bi bi-lock-fill"></i>
      </div>

      <h3 style="color: #fff; font-size: 1.2rem; font-weight: 800; margin-bottom: 8px;">Acceso de Prueba Pausado</h3>
      <p id="auth-blocked-message" style="color: var(--text-secondary); font-size: 0.84rem; line-height: 1.45; margin-bottom: 18px;">
        Tu periodo de prueba ha finalizado o ha sido pausado por el administrador del sistema.
      </p>

      <div style="background: rgba(255, 255, 255, 0.03); border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 12px 14px; margin-bottom: 18px; text-align: left;">
        <div style="font-size: 0.74rem; color: var(--gold-light); text-transform: uppercase; font-weight: 700; margin-bottom: 4px;">¿Deseas activar tu barbería?</div>
        <div style="font-size: 0.8rem; color: var(--text-primary); line-height: 1.4;">Comunícate directamente con el creador del sistema para solicitar más días de prueba o adquirir la licencia oficial completa.</div>
      </div>

      <div style="display: flex; flex-direction: column; gap: 8px;">
        <a href="https://wa.me/?text=Hola,%20quisiera%20solicitar%20activaci%C3%B3n%20para%20el%20Sistema%20MF%20Barber" target="_blank" class="btn btn-whatsapp" style="width: 100%; padding: 12px; font-weight: 700; font-size: 0.88rem; justify-content: center;">
          <i class="bi bi-whatsapp"></i> Solicitar Activación / Licencia
        </a>
        <button type="button" class="btn btn-outline btn-sm" onclick="Auth.hideBlockedModal(); Auth.showLoginModal(); Auth.toggleLoginMode('admin');" style="margin-top: 4px;">
          <i class="bi bi-shield-lock"></i> Soy el Administrador (Ingresar como Maestro)
        </button>
      </div>
    </div>
  </div>
</div>

<!-- Modal: Master Trial & License Control Panel -->
<div class="modal-overlay" id="modal-master-control" onclick="if(event.target === this) Auth.closeMasterControlModal()">
  <div class="modal-box" style="max-width: 520px;">
    <div class="modal-header">
      <h3 style="display: flex; align-items: center; gap: 8px; color: #fff;">
        <i class="bi bi-shield-lock-fill text-gold"></i> Control de Licencia y Acceso Demo
      </h3>
      <button type="button" class="modal-close-btn" onclick="Auth.closeMasterControlModal()" title="Cerrar ventana">&times;</button>
    </div>

    <div class="modal-body">
      <!-- Live Status Card -->
      <div class="master-control-box">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; flex-wrap: wrap; gap: 8px;">
          <div>
            <div style="font-size: 0.72rem; color: var(--text-muted); text-transform: uppercase; font-weight: 700; letter-spacing: 0.05em;">Estado del Usuario de Prueba (demo):</div>
            <div style="margin-top: 3px;">
              <span id="master-demo-status-badge" class="badge badge-emerald">Consultando...</span>
            </div>
          </div>
          <button type="button" id="btn-master-toggle-demo" class="btn btn-danger btn-sm" onclick="Auth.toggleDemo(0)">
            <i class="bi bi-pause-fill"></i> Desactivar Acceso Demo Ya
          </button>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 10px; padding-top: 10px; border-top: 1px solid var(--border-subtle);">
          <div>
            <div style="font-size: 0.7rem; color: var(--text-muted);">Vencimiento Actual:</div>
            <div id="master-demo-expiry-text" style="font-family: var(--font-mono); font-weight: 700; color: #fff; font-size: 0.88rem;">-</div>
          </div>
          <div>
            <div style="font-size: 0.7rem; color: var(--text-muted);">Tiempo Restante:</div>
            <div id="master-demo-remaining-text" style="font-family: var(--font-mono); font-weight: 700; color: var(--gold-light); font-size: 0.88rem;">-</div>
          </div>
        </div>
      </div>

      <!-- Quick Days Add Buttons -->
      <div class="master-control-box">
        <label style="font-size: 0.82rem; font-weight: 700; color: #fff; margin-bottom: 4px; display: block;">
          <i class="bi bi-clock-history text-gold"></i> Asignar / Extender Tiempo de Prueba:
        </label>
        <p style="font-size: 0.76rem; color: var(--text-muted); margin-bottom: 8px;">
          Elige cuántos días deseas habilitar. Si estaba vencido o pausado, se reactivará de inmediato:
        </p>
        <div class="master-action-grid">
          <button type="button" class="btn btn-secondary btn-sm" onclick="Auth.extendDemo(1, this)" style="font-weight: 700;">+ 1 Día</button>
          <button type="button" class="btn btn-secondary btn-sm" onclick="Auth.extendDemo(3, this)" style="font-weight: 700;">+ 3 Días</button>
          <button type="button" class="btn btn-secondary btn-sm" onclick="Auth.extendDemo(7, this)" style="font-weight: 700;">+ 7 Días</button>
          <button type="button" class="btn btn-gold btn-sm" onclick="Auth.extendDemo(30, this)" style="font-weight: 700;">+ 30 Días</button>
        </div>
      </div>

      <!-- Specific Custom Expiration Date -->
      <div class="master-control-box">
        <label style="font-size: 0.82rem; font-weight: 700; color: #fff; margin-bottom: 6px; display: block;">
          <i class="bi bi-calendar-event text-gold"></i> O define fecha y hora de vencimiento exacta:
        </label>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          <input type="datetime-local" id="master-custom-expiry-input" class="form-control" style="flex: 1; min-width: 200px; font-size: 0.84rem; height: 38px;">
          <button type="button" id="btn-save-master-expiry" class="btn btn-outline-gold btn-sm" onclick="Auth.setCustomExpiry()" style="font-weight: 700; height: 38px; display: inline-flex; align-items: center; gap: 6px;">
            <i class="bi bi-check-lg"></i> Guardar Fecha
          </button>
        </div>
      </div>

      <!-- Credentials & Demo Maintenance -->
      <div class="master-control-box" style="margin-bottom: 0;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
          <div style="font-size: 0.82rem; font-weight: 700; color: #fff;"><i class="bi bi-key text-gold"></i> Credenciales de Acceso:</div>
        </div>
        <div style="font-size: 0.78rem; color: var(--text-secondary); line-height: 1.5; margin-bottom: 10px;">
          • <strong>Usuario Demo:</strong> <code>demo</code> / clave: <code>demo123</code> (o botón de 1 clic)<br>
          • <strong>Usuario Maestro:</strong> <code>admin</code> / clave: <code>admin123</code>
        </div>
        <button type="button" class="btn btn-outline btn-sm" onclick="Auth.resetDemoData()" style="font-size: 0.78rem; width: 100%;">
          <i class="bi bi-arrow-counterclockwise"></i> Limpiar Datos de Prueba y Restaurar Fábrica
        </button>
      </div>
    </div>

    <div class="modal-footer">
      <button type="button" class="btn btn-gold btn-modal-cancel" onclick="Auth.closeMasterControlModal()" style="display: inline-flex; align-items: center; gap: 6px; font-weight: 700;">
        <i class="bi bi-check2"></i> Listo / Cerrar
      </button>
    </div>
  </div>
</div>

<!-- Mobile Bottom Navigation Bar -->
<nav class="mobile-bottom-nav">
  <button class="mobile-nav-btn active" data-view="welcome">
    <i class="bi bi-house-door-fill"></i>
    <span>Inicio</span>
  </button>
  <button class="mobile-nav-btn" data-view="appointments">
    <i class="bi bi-calendar-week-fill"></i>
    <span>Turnos</span>
  </button>
  <button class="mobile-nav-btn pos-btn" data-view="pos">
    <div class="pos-icon-circle">
      <i class="bi bi-lightning-charge-fill"></i>
    </div>
    <span>Venta</span>
  </button>
  <button class="mobile-nav-btn" data-view="clients">
    <i class="bi bi-people-fill"></i>
    <span>Clientes</span>
  </button>
  <button class="mobile-nav-btn" data-view="sales">
    <i class="bi bi-bar-chart-line-fill"></i>
    <span>Reportes</span>
  </button>
</nav>

<!-- Toast Notifications Container -->
<div class="toast-container" id="toast-container"></div>

<!-- Custom Scripts -->
<script src="assets/js/offline-db.js?v=<?= time() ?>"></script>
<script src="assets/js/auth.js?v=<?= time() ?>"></script>
<script src="assets/js/app.js?v=<?= time() ?>"></script>
<script src="assets/js/dashboard.js?v=<?= time() ?>"></script>
<script src="assets/js/appointments.js?v=<?= time() ?>"></script>
<script src="assets/js/clients.js?v=<?= time() ?>"></script>
<script src="assets/js/services.js?v=<?= time() ?>"></script>
<script src="assets/js/inventory.js?v=<?= time() ?>"></script>
<script src="assets/js/pos.js?v=<?= time() ?>"></script>
<script src="assets/js/sales.js?v=<?= time() ?>"></script>

</body>
</html>
